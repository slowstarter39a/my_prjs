#ifndef MYPOW_H
#define MYPOW_H

int my_pow(int a, int b);

#endif
